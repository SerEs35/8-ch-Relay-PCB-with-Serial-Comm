namespace Serial_rs232
{
    partial class Serial_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.relay_1 = new System.Windows.Forms.CheckBox();
            this.relay_5 = new System.Windows.Forms.CheckBox();
            this.relay_2 = new System.Windows.Forms.CheckBox();
            this.relay_6 = new System.Windows.Forms.CheckBox();
            this.relay_3 = new System.Windows.Forms.CheckBox();
            this.relay_7 = new System.Windows.Forms.CheckBox();
            this.relay_4 = new System.Windows.Forms.CheckBox();
            this.relay_8 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Enviar_bt = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Escuchar_bt = new System.Windows.Forms.Button();
            this.txt_1 = new System.Windows.Forms.TextBox();
            this.hear_1 = new System.Windows.Forms.TextBox();
            this.desconectar_bt = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // relay_1
            // 
            this.relay_1.AutoSize = true;
            this.relay_1.Location = new System.Drawing.Point(16, 19);
            this.relay_1.Name = "relay_1";
            this.relay_1.Size = new System.Drawing.Size(62, 17);
            this.relay_1.TabIndex = 0;
            this.relay_1.Text = "Relay 1";
            this.relay_1.UseVisualStyleBackColor = true;
            // 
            // relay_5
            // 
            this.relay_5.AutoSize = true;
            this.relay_5.Location = new System.Drawing.Point(102, 19);
            this.relay_5.Name = "relay_5";
            this.relay_5.Size = new System.Drawing.Size(62, 17);
            this.relay_5.TabIndex = 1;
            this.relay_5.Text = "Relay 5";
            this.relay_5.UseVisualStyleBackColor = true;
            // 
            // relay_2
            // 
            this.relay_2.AutoSize = true;
            this.relay_2.Location = new System.Drawing.Point(16, 43);
            this.relay_2.Name = "relay_2";
            this.relay_2.Size = new System.Drawing.Size(62, 17);
            this.relay_2.TabIndex = 2;
            this.relay_2.Text = "Relay 2";
            this.relay_2.UseVisualStyleBackColor = true;
            // 
            // relay_6
            // 
            this.relay_6.AutoSize = true;
            this.relay_6.Location = new System.Drawing.Point(102, 43);
            this.relay_6.Name = "relay_6";
            this.relay_6.Size = new System.Drawing.Size(62, 17);
            this.relay_6.TabIndex = 3;
            this.relay_6.Text = "Relay 6";
            this.relay_6.UseVisualStyleBackColor = true;
            // 
            // relay_3
            // 
            this.relay_3.AutoSize = true;
            this.relay_3.Location = new System.Drawing.Point(16, 67);
            this.relay_3.Name = "relay_3";
            this.relay_3.Size = new System.Drawing.Size(62, 17);
            this.relay_3.TabIndex = 4;
            this.relay_3.Text = "Relay 3";
            this.relay_3.UseVisualStyleBackColor = true;
            // 
            // relay_7
            // 
            this.relay_7.AutoSize = true;
            this.relay_7.Location = new System.Drawing.Point(102, 67);
            this.relay_7.Name = "relay_7";
            this.relay_7.Size = new System.Drawing.Size(62, 17);
            this.relay_7.TabIndex = 5;
            this.relay_7.Text = "Relay 7";
            this.relay_7.UseVisualStyleBackColor = true;
            // 
            // relay_4
            // 
            this.relay_4.AutoSize = true;
            this.relay_4.Location = new System.Drawing.Point(16, 91);
            this.relay_4.Name = "relay_4";
            this.relay_4.Size = new System.Drawing.Size(62, 17);
            this.relay_4.TabIndex = 6;
            this.relay_4.Text = "Relay 4";
            this.relay_4.UseVisualStyleBackColor = true;
            // 
            // relay_8
            // 
            this.relay_8.AutoSize = true;
            this.relay_8.Location = new System.Drawing.Point(102, 91);
            this.relay_8.Name = "relay_8";
            this.relay_8.Size = new System.Drawing.Size(62, 17);
            this.relay_8.TabIndex = 7;
            this.relay_8.Text = "Relay 8";
            this.relay_8.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.relay_8);
            this.groupBox1.Controls.Add(this.relay_4);
            this.groupBox1.Controls.Add(this.relay_7);
            this.groupBox1.Controls.Add(this.relay_3);
            this.groupBox1.Controls.Add(this.relay_6);
            this.groupBox1.Controls.Add(this.relay_2);
            this.groupBox1.Controls.Add(this.relay_5);
            this.groupBox1.Controls.Add(this.relay_1);
            this.groupBox1.Location = new System.Drawing.Point(41, 117);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 120);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // Enviar_bt
            // 
            this.Enviar_bt.Location = new System.Drawing.Point(86, 243);
            this.Enviar_bt.Name = "Enviar_bt";
            this.Enviar_bt.Size = new System.Drawing.Size(75, 23);
            this.Enviar_bt.TabIndex = 10;
            this.Enviar_bt.Text = "Enviar";
            this.Enviar_bt.UseVisualStyleBackColor = true;
            this.Enviar_bt.Click += new System.EventHandler(this.Enviar_bt_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Location = new System.Drawing.Point(41, 24);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox1.Size = new System.Drawing.Size(180, 96);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "Para activar:\nMarque la(s) casilla(s) que desee y presione el boton Enviar.\n\nPara" +
                " desactivar:\nDesmarque la(s) casilla(s) que desee y presione el boton Enviar.\n";
            // 
            // Escuchar_bt
            // 
            this.Escuchar_bt.Location = new System.Drawing.Point(41, 282);
            this.Escuchar_bt.Name = "Escuchar_bt";
            this.Escuchar_bt.Size = new System.Drawing.Size(116, 23);
            this.Escuchar_bt.TabIndex = 17;
            this.Escuchar_bt.Text = "Escuchar puerto";
            this.Escuchar_bt.UseVisualStyleBackColor = true;
            this.Escuchar_bt.Click += new System.EventHandler(this.Escuchar_bt_Click);
            // 
            // txt_1
            // 
            this.txt_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_1.Location = new System.Drawing.Point(174, 245);
            this.txt_1.Name = "txt_1";
            this.txt_1.ReadOnly = true;
            this.txt_1.Size = new System.Drawing.Size(47, 20);
            this.txt_1.TabIndex = 12;
            // 
            // hear_1
            // 
            this.hear_1.Location = new System.Drawing.Point(174, 284);
            this.hear_1.Name = "hear_1";
            this.hear_1.ReadOnly = true;
            this.hear_1.Size = new System.Drawing.Size(61, 20);
            this.hear_1.TabIndex = 18;
            // 
            // desconectar_bt
            // 
            this.desconectar_bt.Location = new System.Drawing.Point(41, 313);
            this.desconectar_bt.Name = "desconectar_bt";
            this.desconectar_bt.Size = new System.Drawing.Size(78, 23);
            this.desconectar_bt.TabIndex = 19;
            this.desconectar_bt.Text = "Desconectar";
            this.desconectar_bt.UseVisualStyleBackColor = true;
            this.desconectar_bt.Click += new System.EventHandler(this.desconectar_bt_Click);
            // 
            // Serial_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(273, 348);
            this.Controls.Add(this.desconectar_bt);
            this.Controls.Add(this.hear_1);
            this.Controls.Add(this.Escuchar_bt);
            this.Controls.Add(this.txt_1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Enviar_bt);
            this.Controls.Add(this.groupBox1);
            this.Name = "Serial_Form";
            this.Text = "Puerto Serial RS232";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Enviar_bt;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.CheckBox relay_1;
        private System.Windows.Forms.CheckBox relay_5;
        private System.Windows.Forms.CheckBox relay_2;
        private System.Windows.Forms.CheckBox relay_6;
        private System.Windows.Forms.CheckBox relay_3;
        private System.Windows.Forms.CheckBox relay_7;
        private System.Windows.Forms.CheckBox relay_4;
        private System.Windows.Forms.CheckBox relay_8;
        private System.Windows.Forms.Button Escuchar_bt;
        private System.Windows.Forms.TextBox txt_1;
        private System.Windows.Forms.TextBox hear_1;
        private System.Windows.Forms.Button desconectar_bt;

    }
}

