/* Sergio E. 20411117  Desarrollo de aplicaciones Web */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

//--------------Nuevo-------------------
using System.IO.Ports;
using System.Net.Sockets;
using System.Net;
//--------------------------------------

namespace Serial_rs232
{
    public partial class Serial_Form : Form
    {
        bool var;           // variable de verdad para poder cerrar el ciclo while y cerrar el socket
                            // al apretar el boton Desconectar
        public Serial_Form()
        {
            InitializeComponent();           
        }

        private void Enviar_bt_Click(object sender, EventArgs e)
        {
            int dato;  
            dato = 0;   //servira como mascara para aplicar un XOR

            if( relay_1.Checked == true) 
            { dato = dato ^ 1; }

            if (relay_2.Checked == true)
            { dato = dato ^ 2; }

            if (relay_3.Checked == true)
            { dato = dato ^ 4; }

            if (relay_4.Checked == true)
            { dato = dato ^ 8; }

            if (relay_5.Checked == true)
            { dato = dato ^ 16; }

            if (relay_6.Checked == true)
            { dato = dato ^ 32; }

            if (relay_7.Checked == true)
            { dato = dato ^ 64; }

            if (relay_8.Checked == true)
            { dato = dato ^ 128; }

            txt_1.Text = dato.ToString();   // solo sirve para Debuggin
           // Puerto_Serial(dato);          // funcion para enviar al puerto serial
        }

        private static void Puerto_Serial(int dato) 
        { 
            SerialPort port = new SerialPort("COM1", 9600, Parity.None, 8, StopBits.One); //parametros
            port.Open();
            port.Write(new byte[] {(byte)dato},0,1); 
            port.Close(); 
        }

   


        private void desconectar_bt_Click(object sender, EventArgs e)
        {
            var = false;
        }

        private void Escuchar_bt_Click(object sender, EventArgs e)
        {
            IPAddress host = IPAddress.Parse("127.0.0.1");
            IPEndPoint ip = new IPEndPoint(host, 9999); //IPEndPoint ip = new IPEndPoint(IPAddress.Any, 9999);
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            socket.Bind(ip);
            socket.Listen(10);
            byte[] data;
            var = true;

  
                while (var == true)
                {

                    Socket client = socket.Accept();
                    IPEndPoint clientep = (IPEndPoint)client.RemoteEndPoint;   //DEBUG  se traba al llegar aqui

                    data = new byte[4];  
                    int receivedDataLength = client.Receive(data);

                    string cadena = Encoding.ASCII.GetString(data, 0, receivedDataLength);
                    hear_1.Text = cadena;

                    client.Send(data, receivedDataLength, SocketFlags.None);
                    client.Close();

                }

            socket.Close();
        }

    }//class serial_form

}//namespace



